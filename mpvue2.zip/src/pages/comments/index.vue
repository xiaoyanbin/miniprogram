<template>
<div><br/><br/><br/><br/><br/>评论列表</div>

</template>

<script>

export default {
  created () {
    console.log(444)
  },
  methods: {
    increment () {
    },
    decrement () {
      
    }
  },
  
}
</script>

<style>
</style>
